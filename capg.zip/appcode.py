# [theme]
# base="light"
# backgroundColor="#efe9e9"
# secondaryBackgroundColor="#ccd4e4"
# font="serif"

import streamlit as st
import cv2
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import os
from yolov5_files.detect import run

# st.markdown(f'<p style="background-color:#efe9e9;color:#33ff33;font-size:24px;border-radius:2%;"></p>', unsafe_allow_html=True)
yolo_path="./"
def obj_detection(my_img, weightsPath, configPath, lpath, score_threshold, nms_threshold):
    st.set_option('deprecation.showPyplotGlobalUse', False)
    st.backgroundColor = "#efe9e9"
    # YOLO model
    net = cv2.dnn.readNetFromDarknet(configPath, weightsPath)
    labels = open(lpath).read().strip().split("\n")
    
    names_of_layer = net.getLayerNames()
    #print(names_of_layer)
    output_layers = [names_of_layer[i-1] for i in net.getUnconnectedOutLayers()]

    colors = np.random.uniform(0,255,size=(len(labels), 3))   


    # Image loading
    newImage = np.array(my_img.convert('RGB'))
    img = cv2.cvtColor(newImage,1)
    height,width,channels = img.shape


    # Objects detection (Converting into blobs)
    blob = cv2.dnn.blobFromImage(img, 0.00392, (416,416), (0,0,0), True, crop = False)   #(image, scalefactor, size, mean(mean subtraction from each layer), swapRB(Blue to red), crop)

    net.setInput(blob)
    outputs = net.forward(output_layers)

    classID = []
    confidences = []
    boxes =[]

    # SHOWING INFORMATION CONTAINED IN 'outputs' VARIABLE ON THE SCREEN
    for op in outputs:
        for detection in op:
            scores = detection[5:]
            class_id = np.argmax(scores)  
            confidence = scores[class_id] 
            if confidence > 0.5:   
                # OBJECT DETECTED
                #Get the coordinates of object: center,width,height  
                center_x = int(detection[0] * width)
                center_y = int(detection[1] * height)
                w = int(detection[2] * width)  #width is the original width of image
                h = int(detection[3] * height) #height is the original height of the image

                # RECTANGLE COORDINATES
                x = int(center_x - w /2)   #Top-Left x
                y = int(center_y - h/2)   #Top-left y

                #To organize the objects in array so that we can extract them later
                boxes.append([x,y,w,h])
                confidences.append(float(confidence))
                classID.append(class_id)


    indexes = cv2.dnn.NMSBoxes(boxes, confidences,score_threshold,nms_threshold)      

    items = []
    for i in range(len(boxes)):
        if i in indexes:
            x,y,w,h = boxes[i]
            #To get the name of object
            label = str.upper((labels[classID[i]]))   
            #color = colors[i]
            color = [int(c) for c in colors[classID[i]]]
            cv2.rectangle(img,(x,y),(x+w,y+h),color,4)
            text = "{}: {:.4f}".format(labels[classID[i]], confidences[i])
            cv2.putText(img, text, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 1.0 , color, 3)
            items.append(label)

    
    st.image(img)
  
    if len(indexes)>1:
        st.success("Found {} Objects - {}".format(len(indexes),[item for item in set(items)]))
    else:
        st.success("Found {} Object - {}".format(len(indexes),[item for item in set(items)]))


def main():
    st.title("Object Detection")
    st.write("You can view real-time object detection done using YOLO model here. Select one of the following options to proceed:")
    
    st.sidebar.image(Image.open('capg.png'))
    # source = ("Yolo-Apple", "Yolo-Server", "Yolo-Server-Rack-Router", "Yolo-TLMK", "Yolov5-Server-Rack")
    source = ("Yolov5-Server-Rack", "Yolov5-Server-Rack-Router", "Yolov4-Server-Rack-Router", "Yolov4-Server", "Yolov4-TLMK", "Yolov3-Apple")
    source_index = st.sidebar.selectbox("Select the model", range(len(source)), format_func=lambda x: source[x]) 
    
    model = False
    is_valid = False
    
    if source_index == 5:
        # st.write('you selected yolo model trained on apple objects, kindly upload the image to detect apples in an image')
        uploaded_file = st.sidebar.file_uploader("Upload image", type=['png', 'jpeg', 'jpg', 'JPG'])
        if uploaded_file is not None:
            is_valid = True
            with st.spinner(text='loading...'):
                picture = Image.open(uploaded_file)
                st.sidebar.image(picture)
                # picture = picture.save(f'data/images/{uploaded_file.name}')
                lpath=os.path.sep.join([yolo_path, 'yolov3_apple/apple.names'])
                weightsPath = os.path.sep.join([yolo_path, "yolov3_apple/yolov3_apple.weights"])
                configPath = os.path.sep.join([yolo_path, "yolov3_apple/yolov3_apple.cfg"])
                model = 'v4'
        else:
            is_valid = False
    
    
    
    elif source_index == 3:
        uploaded_file = st.sidebar.file_uploader("Upload image", type=['png', 'jpeg', 'jpg', 'JPG'])
        if uploaded_file is not None:
            is_valid = True
            with st.spinner(text='loading...'):
                picture = Image.open(uploaded_file)
                st.sidebar.image(picture)
                # picture = picture.save(f'data/images/{uploaded_file.name}')
                lpath=os.path.sep.join([yolo_path, 'yolov4_server/server.names'])
                weightsPath = os.path.sep.join([yolo_path, "yolov4_server/yolov4-server.weights"])
                configPath = os.path.sep.join([yolo_path, "yolov4_server/yolov4-server.cfg"])
                model = 'v4'
        else:
            is_valid = False
            
            
            
    elif source_index == 2:
        uploaded_file = st.sidebar.file_uploader("Upload image", type=['png', 'jpeg', 'jpg', 'JPG'])
        if uploaded_file is not None:
            is_valid = True
            with st.spinner(text='loading...'):
                picture = Image.open(uploaded_file)
                st.sidebar.image(picture)
                # picture = picture.save(f'data/images/{uploaded_file.name}')
                lpath=os.path.sep.join([yolo_path, 'yolov4_server_rack_router/server_rack_router.names'])
                weightsPath = os.path.sep.join([yolo_path, "yolov4_server_rack_router/yolov4-server_rack_router.weights"])
                configPath = os.path.sep.join([yolo_path, "yolov4_server_rack_router/yolov4-server_rack_router.cfg"])
                model = 'v4'   
        else:
            is_valid = False
            
       
            
    elif source_index == 4:
        uploaded_file = st.sidebar.file_uploader("upload image", type=['png', 'jpeg', 'jpg', 'JPG'])
        if uploaded_file is not None:
            is_valid = True 
            with st.spinner(text='loading...'):
                picture = Image.open(uploaded_file)
                st.sidebar.image(picture)
                # picture = picture.save(f'data/images/{uploaded_file.name}')
                lpath=os.path.sep.join([yolo_path, 'yolov4_TLMK/tlmk.names'])
                weightsPath = os.path.sep.join([yolo_path, "yolov4_TLMK/yolov4_TLMK.weights"])
                configPath = os.path.sep.join([yolo_path, "yolov4_TLMK/yolov4_TLMK.cfg"])
                model = 'v4'   
        else:
            is_valid = False
    
    
    
    elif source == 1:
        uploaded_file = st.sidebar.file_uploader("Upload image", type=['png', 'jpeg', 'jpg', 'JPG'])
        if uploaded_file is not None:
            is_valid = True
            with st.spinner(text='loading...'):
                picture = Image.open(uploaded_file)
                st.sidebar.image(picture)
                picture = picture.save(f'yolov5_files/data1/images/{uploaded_file.name}')
                model = 'v5'
                weightsPath = os.path.sep.join([yolo_path, "yolov5_server_rack_router/best.pt"])
        else:
            is_valid = False
    
    
    
    else:
        uploaded_file = st.sidebar.file_uploader("Upload image", type=['png', 'jpeg', 'jpg', 'JPG'])
        if uploaded_file is not None:
            is_valid = True
            with st.spinner(text='loading...'):
                picture = Image.open(uploaded_file)
                st.sidebar.image(picture)
                picture = picture.save(f'yolov5_files/data1/images/{uploaded_file.name}')
                weightsPath = os.path.sep.join([yolo_path, "yolov5_server_rack/best.pt"])
                model = 'v5'
        else:
            is_valid = False 
            
            
            
    score_threshold = st.sidebar.slider("Confidence_threshold", 0.00,1.00,0.5,0.01)
    nms_threshold = st.sidebar.slider("NMS_threshold", 0.00, 1.00, 0.4, 0.01)         

    if is_valid:
        print('valid')
        if st.button('detect'):
            if model == 'v4':
                obj_detection(picture,weightsPath, configPath, lpath, score_threshold, nms_threshold)
            elif model == 'v5':
                img = run(weights=weightsPath, save_txt='{uploaded_file.name}.txt', conf_thres=score_threshold, source=f'yolov5_files/data1/images/{uploaded_file.name}')
                st.image(img, channels='BGR')
                
                directory = 'yolov5_files/runs/detect/'
                runs_print = max([os.path.join(directory,d) for d in os.listdir(directory)], key=os.path.getmtime)
                print(runs_print)
                
                # for file in os.listdir(runs_print):
                if os.path.exists(f"{runs_print}/labels/{uploaded_file.name.split('.')[0]}.txt"):
                    with open(f"{runs_print}/labels/{uploaded_file.name.split('.')[0]}.txt", 'r') as f:
                        line = f.readlines()
                        st.success("Found {} Objects".format(len(line),))
                else:
                    st.success("Found [0] Objects")
              
       
 

if __name__ == '__main__':
    main()

