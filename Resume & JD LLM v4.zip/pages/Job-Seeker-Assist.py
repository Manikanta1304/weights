import streamlit as st
import google.generativeai as genai
import os
import PyPDF2 as pdf
from dotenv import load_dotenv
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import seaborn as sns
import json
import pandas as pd

st.set_page_config(page_title="ATS Resume Expert", layout='wide')

load_dotenv() ## load all our environment variables

genai.configure(api_key=os.getenv("api_key"))

def get_gemini_repsonse(prompt): #, pdf_content):
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(prompt) #, pdf_content])
    return response.text

def input_pdf_text(uploaded_file):
    reader = pdf.PdfReader(uploaded_file)
    text = ""
    for page in range(len(reader.pages)):
        page = reader.pages[page]
        text += str(page.extract_text())
    return text


## streamlit app
left, right = st.columns([1.3,1])

with left:
    st.title("Job Seeker - Smart ATS")
    st.text("Improve Your Resume ATS")

    div1, div2 = st.columns([1.3,1])

    with div1:
        uploaded_file = st.file_uploader("Upload Your Resume", type="pdf", help="Please upload PDF resume")

    with div2:
        job_roles = ["Data Scientist", "Software Engineer", "Marketing Manager"]  # Example job roles
        selected_job_role = st.selectbox("Select Job Role", job_roles)

    # Add textbox for job description
    job_description = st.text_area("Enter Job Description", "")

    submit = st.button("Submit")
    
    if submit:
        if uploaded_file is not None:
            pdf_content = input_pdf_text(uploaded_file)

            seeker_prompt = f"""
            Task:
            As an experienced ATS Resume Parser assistant, your objective is to review the provided resume content and evaluate it for the role of {selected_job_role}. 
            Your aim is to provide a response that allows the individual to leverage this analysis to refine the resume and maximize career prospects.

            Please find the details below:
            
            Job Role: {selected_job_role}
            
            Job Description: {job_description}

            Resume Content: {pdf_content}

            Please provide the following response tailored to the job role of {selected_job_role} and the provided job description:

            1. Resume Suitability: 
                - Provide a brief assessment of whether the individual's skills and experience align with the requirements outlined in the job description.

            2. Resume Summary:
                - Summarize the key strengths and areas for improvement in the resume.

            3. Top 5 Keywords:
                - List the top keywords or skills highlighted in the resume relevant to the job role.

            Additionally, based on the extracted information, please provide the following:
            - Recommendations on upskilling: List of skills or areas of expertise the candidate could benefit from improving or acquiring.
            - Certification recommendations: List few relevant certifications that could enhance the candidate's profile.

            Additional Information:
            - Ensure accuracy and completeness in the extracted information. Return only the extracted data. Nothing else.
            - Pay attention to any formatting or structure variations in the provided resume content.
            - If any information is missing or unclear, feel free to make reasonable assumptions.

            Scoring:
            - Evaluate the resume on a scale of 1-10, where:
                - 1 indicates a poor match for the desired position or role.
                - 10 indicates an excellent match with extensive experience and relevant skills.

            Please provide the score along with the extracted information.

            Output Format:
            Please provide the extracted information strictly in a dictionary format.
            """


            response = get_gemini_repsonse(seeker_prompt) #, pdf_content)
            response = response.replace("```", "")
            print('response', response)
            json_response = json.loads(response)

            df = pd.DataFrame.from_dict(json_response, orient='index').transpose()
            st.dataframe(df[df.columns[2:]], height=100, hide_index=True)

            st.write('Resume Suitability:', json_response['Resume Suitability'])
            st.write('Resume Summary:', json_response['Resume Summary'])

            with right:
                # Generate word cloud for resume summary
                summary_start_idx = response.find("Resume Summary:") + len("Resume Summary:")
                summary_end_idx = response.find("=======", summary_start_idx)
                summary = response[summary_start_idx:summary_end_idx].strip()

                fig, ax = plt.subplots(figsize=(8, 6))
                wordcloud = WordCloud(width=800, height=400, background_color="white").generate(summary)
                ax.imshow(wordcloud, interpolation="bilinear")
                ax.axis("off")
                ax.set_title(f"Top words in the resume: {uploaded_file.name}")
                st.pyplot(fig)

                # Plot pie chart
                weights = [1] * len(json_response['Top 5 Keywords'])
                fig, ax = plt.subplots(figsize=(8, 6))
                ax.pie(weights, labels=json_response['Top 5 Keywords'])
                ax.set_title('Top 5 Keywords in Resume')
                ax.axis('equal')
                st.pyplot(fig)